from django.utils.text import slugify
import hashlib
import os


class UserMiddleware:
  def __init__(self, get_response):
    self.get_response = get_response

  def __call__(self, request):
    user_id = request.COOKIES.get('user')
    if not user_id:
      user_id = hashlib.md5(os.urandom(16)).hexdigest()
    else:
      user_id = slugify(user_id)

    user_dir = os.path.join('media', user_id)

    if not os.path.exists(user_dir):
      os.makedirs(user_dir)
      os.makedirs(os.path.join(user_dir, 'thumbs'))

    request.user_id = user_id

    response = self.get_response(request)
    response.set_cookie('user', user_id)

    return response
