from django import forms

import imghdr


class ImageForm(forms.Form):
  image = forms.FileField()

  def clean_image(self):
    content = self.cleaned_data['image']

    if content.size > 200000:
      raise forms.ValidationError('File too large')

    if imghdr.what(content) not in ['png', 'jpg', 'jpeg']:
      raise forms.ValidationError('Bad file type')

    return content