<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="letters" tilewidth="32" tileheight="32" tilecount="72" columns="36">
 <image source="letters.png" width="1152" height="64"/>
 <tile id="23">
  <properties>
   <property name="print_spec" value="X"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="print_spec" value="Y"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="print_spec" value="Z"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="print_spec" value="X"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="print_spec" value="Y"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="print_spec" value="Z"/>
  </properties>
 </tile>
</tileset>
