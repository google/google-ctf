<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="tileset" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="48" columns="8">
 <image source="../../images/tmw_desert_spacing.png" trans="ff00ff" width="265" height="199"/>
</tileset>
