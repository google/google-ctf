# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from gametree import *
import components.grate_door
import settings
import persistent_state
import keys
import gametree
if settings.environ == 'client':
    from menus import chat

class BucketWall(serialize.SerializableObject):
    def __init__(self, entity):
        self.entity = entity

    def on_open(self):
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Greetings, Player. Beyond lies the most powerful artifact in the entire Kingdom: the Bucket. Use it well.", choices=["Thank you. I will treasure this gift."])

    def on_query(self, txt):
        if "Thank you" in txt:
            self.entity.parent.remove_child(self.entity)
        pass

class UnlikedNPC(serialize.SerializableObject):
    def __init__(self):
        self.annoyed = False

    def on_open(self):
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Oh come on, not you again...")

    def on_query(self, txt):
        txt = txt.lower()
        if "weather" in txt:
            reply = "The weather could not be much worse..."
        elif "good" in txt:
            reply = "It's not good at all."
        elif "old potato" in txt:
            reply = "WHAT DID YOU CALL ME?! I'LL TELL YOUR MOTHER, YOUNG MAN!"
            self.annoyed = True
        else:
            reply = "What do you want, whippersnapper?"
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply)


class UnlikedGuardNPC(serialize.SerializableObject):
    introduction = [
        "How's it going?",
        "Yeah, I'm good too. Though that guy out there is annoying me...",
        "Someone should finally tell him what they think of him!",
        "How about calling him an 'old potato'?",
        "I bet you're afraid!"
    ]
    def __init__(self, flag_door, unliked_npc):
        self.counter = 0
        for comp in flag_door.components:
            if isinstance(comp, components.grate_door.GrateDoor):
                self.flag_door = comp
        for comp in unliked_npc.components:
            if isinstance(comp, components.npc.NPC):
                self.unliked_npc = comp

    def on_open(self):
        if settings.environ == "client":
            if self.counter < len(self.introduction) or self.unliked_npc.npc.annoyed:
                environ.client.pending_chat = chat.ChatMenu(environ.game, "Hello!")
            else:
                environ.client.pending_chat = chat.ChatMenu(environ.game, self.introduction[-1])

    def on_query(self, txt):
        if self.counter < len(self.introduction):
            reply = self.introduction[self.counter]
            self.counter += 1
        else:
            if self.unliked_npc.npc.annoyed:
                reply = "Wow, I did not expect you would actually do that! I unlocked the door for you."
                print("Door unlocked.")
                self.flag_door.locked = False
            else:
                reply = self.introduction[-1]

        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply)


class AnimalNPC(serialize.SerializableObject):

    def __init__(self, flag_door):
        for comp in flag_door.components:
            if isinstance(comp, components.grate_door.GrateDoor):
                self.flag_door = comp
        self.reset()
        pass

    def reset(self):
        self.animals = {"cats": 0, "dogs": 0, "fish": 0, "hamsters": 0}
        self.adjectives = {"cats": "cute", "dogs": "smart",
                           "fish": "easy to take care of", "hamsters": "funny"}
        self.question = 0
        self.introduced = False
        self.answer = 0

    def on_open(self):
        self.answer = 0
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Hello!")

    def handle(self, a, b, txt, aftermath):
        if self.answer == 0:
            reply = "Which do you like better: %s or %s?" % (a, b)
            self.answer = 1
        elif self.answer == 1:
            has_a = a in txt.lower()
            has_b = b in txt.lower()
            if has_a and has_b:
                reply = "I cannot afford both."
                self.answer = 0
            elif has_a:
                reply = "Yes, they're so %s!" % self.adjectives[a]
                self.answer = 2
                self.animals[a] += 1
            elif has_b:
                reply = "Yes, they're so %s!" % self.adjectives[b]
                self.answer = 2
                self.animals[b] += 1
            else:
                reply = "Sorry, what?"
                self.answer = 0
        elif self.answer == 2:
            reply = aftermath
            self.question += 1
            self.answer = 0
        return reply

    def on_query(self, txt):
        if txt == "punch":
            reply = "Ow, my head hurts... I forgot what we were talking about, let's start over."
            self.reset()
        elif self.introduced == False:
            if self.answer == 0:
                reply = "My nephew is having a birthday next week!"
                self.answer = 1
            elif self.answer == 1:
                reply = "I think I should get him a pet."
                self.answer = 2
            elif self.answer == 2:
                reply = "But I cannot make my mind which animal - please help me decide!"
                self.introduced = True
                self.answer = 0
        else:
            if self.question == 0:
                reply = self.handle("cats", "dogs", txt, "Though they both act funny in videos.")
            elif self.question == 1:
                reply = self.handle("fish", "hamsters", txt, "Though the other one is pretty cool too.")
            elif self.question == 2:
                reply = "Ok, so that leaves us with just two choices."
                self.question += 1
            elif self.question == 3:
                a, b = None, None
                for k, v in self.animals.items():
                    if v > 0:
                        a, b = b, k
                reply = self.handle(a, b, txt, "Looks like we have a winner then...")
            elif self.question == 4:
                winner, score = None, 0
                for k, v in self.animals.items():
                    if v > score:
                        winner, score = k, v
                reply = "... %s! I'll give one of those to my nephew." % winner
                self.question += 1
            elif self.question == 5:
                dislike = None
                for k, v in self.animals.items():
                    if v == 0:
                        dislike = k
                if dislike is None:
                    reply = "Thanks for your help. To show my gratitude, I opened the door."
                    self.flag_door.locked = False
                else:
                    reply = "But honestly, I don't get how one can dislike %s... They're so %s!" % (dislike, self.adjectives[dislike])

        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply)

class NPC(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initialized = False
        self.npc = None

    def update_animation(self, frameset):
        if frameset != self.entity.frameset:
            self.entity.frameset = frameset

    def tick(self):
        # Cannot do this in __init__, the fields are not set there yet.
        if not self.initialized:
            self.initialized = True
            if self.name == "npc_unliked":
                self.npc = UnlikedNPC()
            elif self.name == "npc_unliked_guard":
                self.npc = UnlikedGuardNPC(self.flag_door, self.unliked_npc)
            elif self.name == "npc_animals":
                self.npc = AnimalNPC(self.flag_door)
            elif self.name == "bucket_wall":
                self.npc = BucketWall(self.entity)
            else:
                raise Exception("Unknown NPC " + self.name)
        if self.npc is not None and hasattr(self.npc, "tick"):
            self.npc.tick()

    def on_activation(self):
        environ.game.now_talking_to = self.npc
        environ.game.now_talking_to.on_open()

    def on_collision_enter(self, other):
        pass

    def while_colliding(self, other):
        pass

    def on_collision_exit(self, other):
        pass

    def duplicate(self, new_entity):
        ret = self.__class__()
        return ret
