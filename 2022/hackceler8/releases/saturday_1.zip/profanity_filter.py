import re

profanities = ["potato", "ninnyhammer", "snollygoster", "mumpsimus"]
def profanity_filter(txt):
    old_txt = txt
    for word in profanities:
        pattern = re.compile(word, re.IGNORECASE)
        txt = pattern.sub("", txt)
    if old_txt != txt:
        return False, txt
    return True, txt
