<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="wall" tilewidth="388" tileheight="448" tilecount="1" columns="1">
 <image source="wall.png" width="388" height="448"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="348" height="448"/>
  </objectgroup>
 </tile>
</tileset>
