<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="character" tilewidth="32" tileheight="40" margin="2" tilecount="208" columns="16">
 <image source="character.png" width="516" height="528"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <properties>
   <property name="frameset" value="up_stand"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="3">
  <properties>
   <property name="frameset" value="up_run"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
  <animation>
   <frame tileid="3" duration="90"/>
   <frame tileid="4" duration="90"/>
   <frame tileid="5" duration="90"/>
   <frame tileid="6" duration="90"/>
   <frame tileid="7" duration="90"/>
   <frame tileid="8" duration="90"/>
  </animation>
 </tile>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="9">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="14">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="15">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="16">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="17">
  <properties>
   <property name="frameset" value="upright_stand"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="18">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="19">
  <properties>
   <property name="frameset" value="upright_run"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
  <animation>
   <frame tileid="19" duration="90"/>
   <frame tileid="20" duration="90"/>
   <frame tileid="21" duration="90"/>
   <frame tileid="22" duration="90"/>
   <frame tileid="23" duration="90"/>
   <frame tileid="24" duration="90"/>
  </animation>
 </tile>
 <tile id="20">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="21">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="22">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="23">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="24">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="26">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="28">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="33">
  <properties>
   <property name="frameset" value="right_stand"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="35">
  <properties>
   <property name="frameset" value="right_run"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
  <animation>
   <frame tileid="35" duration="90"/>
   <frame tileid="36" duration="90"/>
   <frame tileid="37" duration="90"/>
   <frame tileid="38" duration="90"/>
   <frame tileid="39" duration="90"/>
   <frame tileid="40" duration="90"/>
  </animation>
 </tile>
 <tile id="36">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="40">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="49">
  <properties>
   <property name="frameset" value="downright_stand"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="50">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="51">
  <properties>
   <property name="frameset" value="downright_run"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
  <animation>
   <frame tileid="51" duration="90"/>
   <frame tileid="52" duration="90"/>
   <frame tileid="53" duration="90"/>
   <frame tileid="54" duration="90"/>
   <frame tileid="55" duration="90"/>
   <frame tileid="56" duration="90"/>
  </animation>
 </tile>
 <tile id="52">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="53">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="54">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="55">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="56">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="57">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="58">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="64">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="65">
  <properties>
   <property name="frameset" value="down_stand"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="66">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="67">
  <properties>
   <property name="frameset" value="down_run"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
  <animation>
   <frame tileid="67" duration="90"/>
   <frame tileid="68" duration="90"/>
   <frame tileid="69" duration="90"/>
   <frame tileid="70" duration="90"/>
   <frame tileid="71" duration="90"/>
   <frame tileid="72" duration="90"/>
  </animation>
 </tile>
 <tile id="68">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="69">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="70">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="71">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="72">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="73">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="74">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="80">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="81">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="82">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="83">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="84">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="85">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="86">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="87">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="88">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="89">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="90">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="91">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="92">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="96">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="97">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="98">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="99">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="100">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="101">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="102">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="103">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="104">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="105">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="106">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="107">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="108">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="112">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="113">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="114">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="115">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="116">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="117">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="118">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="119">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="120">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="121">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="122">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="123">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="124">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="128">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="129">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="130">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="131">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="132">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="133">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="134">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="135">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="136">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="137">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="138">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="139">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="140">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="141">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="142">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="144">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="145">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="146">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="147">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="148">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="149">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="150">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="151">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="152">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="153">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="154">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="155">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="156">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="160">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="161">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="162">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="163">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="164">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="165">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="166">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="167">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="168">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="169">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="170">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="171">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="172">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="176">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="177">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="178">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="179">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="180">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="181">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="182">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="183">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="184">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="185">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="186">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="187">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="188">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="192">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="193">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="194">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="195">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="196">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="198">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="199">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="28" width="12" height="10"/>
  </objectgroup>
 </tile>
</tileset>
