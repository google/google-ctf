<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="campfire" tilewidth="32" tileheight="32" tilecount="4" columns="4">
 <image source="campfire.png" width="128" height="32"/>
 <tile id="0">
  <properties>
   <property name="frameset" value="campfire"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="3.75" y="0" width="24.25" height="31.75"/>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="200"/>
   <frame tileid="1" duration="200"/>
   <frame tileid="2" duration="200"/>
   <frame tileid="3" duration="200"/>
  </animation>
 </tile>
</tileset>
