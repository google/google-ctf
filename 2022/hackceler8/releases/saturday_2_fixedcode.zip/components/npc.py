# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from gametree import *
import components.grate_door
import settings
import persistent_state
import keys
import gametree
if settings.environ == 'client':
    from menus import chat


class CakeNPC(serialize.SerializableObject):
    INIT = """
    cash = 0
    eggs_price = 3
    milk_price = 2
    flour_price = 2
    sugar_price = 3
    honey_price = 7
    butter_price = 5
    vanilla_price = 4
    cocoa_price = 5

    eggs = 0
    milk = 0
    flour = 0
    sugar = 0
    honey = 0
    butter = 0
    vanilla = 0
    cocoa = 0
    """
    CONDITIONS = """
    main = 0
    main += eggs
    main += milk
    main += flour
    main += butter

    sweet = 0
    sweet += sugar
    sweet += honey

    flavor = 0
    flavor += vanilla
    flavor += cocoa
    """
    def __init__(self, flag):
        self.history = []
        self.flag = flag
        self.reset()
        pass

    def reset(self):
        self.shopping = self.INIT
        self.question = 0

    def parse(self):
        try:
            def value(b):
                if b in res:
                    return res[b]
                try:
                    return int(b)
                except:
                    return b
            res = {}
            for line in self.shopping.splitlines():
                if not line.strip(): continue
                a, op, b = line.split()
                if op == "=":
                    res[a] = value(b)
                elif op == "+=":
                    res[a] += value(b)
                elif op == "-=":
                    res[a] -= value(b)
                else:
                    raise Exception("Unsupported operator")
            return res
        except Exception as e:
            return None

    def add(self, txt):
        self.shopping += "\n" + txt

    def on_open(self):
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Hello!")
        self.reset()

    def on_query(self, txt):
        if self.question == 0:
            reply = "I'd like to bake something tasty for tomorrow."
            self.question += 1
        elif self.question == 1:
            reply = "Please help me prepare a shopping list."
            self.question += 1
        elif self.question == 2:
            reply = "First of all, where should we shop at?"
            self.question += 1
        elif self.question == 3:
            if txt.lower() == "cheapfoodol":
                reply = "Well... They do have lower prices, though the quality is average. Fine."
                delta = -1
            elif txt.lower() == "market":
                reply = "Always a good choice."
                delta = 0
            elif txt.lower() == "premiumfoodex":
                reply = "A steep price, but great quality. Might be a bit too expensive..."
                delta = 2
            elif txt.strip() == "":
                reply = "Well?"
            else:
                reply = "Oh, I don't know that place, let's try it!"
                delta = 0

            if txt.strip() != "":
                self.add("delta = %d" % delta)
                self.add("shop = %s" % txt)
                self.question += 1
            else:
                self.question = 2
        elif self.question == 4:
            reply = "What do you think we should buy?"
            self.question += 1
        elif self.question == 5:
            txt = txt.lower()
            products = ["eggs", "milk", "flour", "sugar", "honey", "butter", "vanilla", "cocoa"]
            if txt == "nothing":
                reply = "Ok, let's see..."
                self.add(self.CONDITIONS)
                self.question += 1
            elif txt.strip() == "":
                reply = "Well?"
                self.question = 4
            elif txt not in products:
                reply = "I don't think we really need it."
            else:
                self.add("cash += %s_price" % txt)
                self.add("cash += delta")
                self.add("%s = 1" % txt)
                reply = "Ok, %s added to the list." % txt
                self.question = 4
        elif self.question == 6:
            res = self.parse()

            if res == None:
                reply = "Damn, I've made a huge inkblot in the shopping list. We need to start over."
                self.reset()
            elif res["main"] < 4:
                reply = "We're missing something... Let's start over."
                self.reset()
            elif res["sweet"] == 0:
                reply = "We're missing something sweet... Let's start over."
                self.reset()
            elif res["flavor"] == 0:
                reply = "We're missing some flavor... Let's start over."
                self.reset()
            elif res["cash"] > 10:
                reply = "It totals to %d dollars. That's way too much for me. Let's try again." % res["cash"]
                self.reset()
            else:
                reply = "Yeah, that sounds about right to me. %s will earn %d dollars from me today!" % (res["shop"], res["cash"])
                self.question += 1
        elif self.question == 7:
            reply = "I'll give you the flag to celebrate!"
            self.flag.dispatch_to_components("on_activation")

        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply)


class NPC(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initialized = False
        self.npc = None

    def update_animation(self, frameset):
        if frameset != self.entity.frameset:
            self.entity.frameset = frameset

    def tick(self):
        # Cannot do this in __init__, the fields are not set there yet.
        if not self.initialized:
            self.initialized = True
            if self.name == "npc_cake":
                self.npc = CakeNPC(self.flag_door)
            else:
                raise Exception("Unknown NPC")
        if self.npc is not None and hasattr(self.npc, "tick"):
            self.npc.tick()

    def on_activation(self):
        environ.game.now_talking_to = self.npc
        environ.game.now_talking_to.on_open()

    def on_collision_enter(self, other):
        pass

    def while_colliding(self, other):
        pass

    def on_collision_exit(self, other):
        pass

    def duplicate(self, new_entity):
        ret = self.__class__()
        return ret
