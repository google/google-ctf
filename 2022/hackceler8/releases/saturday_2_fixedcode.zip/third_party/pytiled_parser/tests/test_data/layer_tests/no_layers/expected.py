from typing import List

from pytiled_parser import layer

EXPECTED: List[layer.Layer] = []
