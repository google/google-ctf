# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from gametree import *
import persistent_state


def gen_framesets():
    ret = {}
    for color in ["red", "orange", "green", "teal", "blue", "purple", "white"]:
        for state in ["unobtained", "obtained"]:
            ret[color + "_" + state] = Frameset(frameset=color + "_" + state)
    return ret


class Flag(Component):
    additional_framesets = gen_framesets()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.status = "unobtained"
        self.color = None

    def added(self):
        self.color, self.status = self.entity.original_frameset.split("_")

    def update_animation(self, frameset):
        if frameset != self.entity.frameset:
            self.entity.frameset = frameset

    def tick(self):
        if persistent_state.persistent_state.obtained_flags.get(self.color, False):
            self.status = "obtained"
        else:
            self.status = "unobtained"

        self.update_animation(self.color + "_" + self.status)

    def while_keys_held(self, keys):
        pass

    def on_activation(self):
        if self.status != "obtained":
            self.status = "obtained"
            persistent_state.persistent_state.obtained_flags[self.color] = True

        self.entity.frameset = self.color + "_" + self.status

    def on_collision_exit(self, other):
        pass
