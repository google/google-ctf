<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="key" tilewidth="32" tileheight="32" tilecount="6" columns="1">
 <image source="key.png" width="32" height="192"/>
 <tile id="0">
  <properties>
   <property name="frameset" value="key_red"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="2" x="2" y="28">
    <polygon points="0,0 12,-14 16,-14 28,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1">
  <properties>
   <property name="frameset" value="key_blue"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="28">
    <polygon points="0,0 12,-14 16,-14 28,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2">
  <properties>
   <property name="frameset" value="key_green"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="28">
    <polygon points="0,0 12,-14 16,-14 28,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="3">
  <properties>
   <property name="frameset" value="key_teal"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="28">
    <polygon points="0,0 12,-14 16,-14 28,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="4">
  <properties>
   <property name="frameset" value="key_purple"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="28">
    <polygon points="0,0 12,-14 16,-14 28,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5">
  <properties>
   <property name="frameset" value="key_orange"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="28">
    <polygon points="0,0 12,-14 16,-14 28,0"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
