<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="letters" tilewidth="32" tileheight="32" tilecount="72" columns="36">
 <image source="letters.png" width="1152" height="64"/>
 <tile id="23">
  <properties>
   <property name="print_spec" value="X"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="print_spec" value="Y"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="print_spec" value="Z"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="z_level" type="int" value="Player_z0"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="z_level" type="int" value="Player_z1"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="z_level" type="int" value="Player_z2"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="z_level" type="int" value="Player_z3"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="z_level" type="int" value="Player_z4"/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="z_level" type="int" value="Player_z5"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="z_level" type="int" value="Player_z6"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="z_level" type="int" value="Player_z7"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="z_level" type="int" value="Player_z8"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="z_level" type="int" value="Player_z9"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="print_spec" value="X"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="print_spec" value="Y"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="print_spec" value="Z"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="z_level" type="int" value="Player_z0"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="z_level" type="int" value="Player_z1"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="z_level" type="int" value="Player_z2"/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="z_level" type="int" value="Player_z3"/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="z_level" type="int" value="Player_z4"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="z_level" type="int" value="Player_z5"/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="z_level" type="int" value="Player_z6"/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="z_level" type="int" value="Player_z7"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="z_level" type="int" value="Player_z8"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="z_level" type="int" value="Player_z9"/>
  </properties>
 </tile>
</tileset>
