// A script to handle cave walls (and likely other walls too later on).

const DST_TILESET = "base_out_atlas";
const DST_LAYER = "GroundAutoWallsDontEdit";

const SRC_LAYER = "Ground0";
const SRC_TILESET = "base_out_atlas";
const SRC_INIT_TILEID = new Set([
  /* Group 0 Cave     */ 1126, 1155, 1156, 1187, 1188, 1189, 1190, 1191,
  /* Group 1 Forest   */ 118, 181, 182, 183, 310, 1170, 1173,
  /* Group 2 Badlands */ 136,
]);
const SRC_BACKGROUND_TILEID = new Set([
  /* Group 0 Cave     */ 1057,
  /* Group 1 Forest   */ 33,
  /* Group 2 Badlands */ 38,
]);

const SRC_TILE_GROUPS = new Map();
function addTilesToGroup(group, tileList) {
  tileList.forEach(e => {
    SRC_TILE_GROUPS.set(e, group);
  });
}

// Cave.
addTilesToGroup(0, [1126, 1155, 1156, 1187, 1188, 1189, 1190, 1191]);
addTilesToGroup(0, [1057]);

// Forest.
addTilesToGroup(1, [118, 181, 182, 183, 310, 1170, 1173]);
addTilesToGroup(1, [33]);

// Badlands.
addTilesToGroup(2, [136]);
addTilesToGroup(2, [38]);

// Format:
// [ candidatePattern, [tileIdGroup0, ...], [tileIdGroup1, ...], ... ]
//   Tile groups are related to different themes (cave, forest, etc).
//   Nth tileIdGroupM is rendered at x,y-N (counting from 0 for center tile in
//   the candidate pattern).
//   Negative tileId denotes an "important" tile - it will not be overwritten by
//   any later matches.
// See tilePatternMatch function for candidate format description.
const SRC_PATTERNS = [
  [ "***"+
    "*x*"+
    "*.*",
    [ 1025 ],
    [ 1 ],
    [ 6 ],
  ],

  [ "*.*"+
    "xxx"+
    "***",
    [ 1153, 1121, 1089 ],
    [ 129, 97, 65 ],
    [ 134, 102, 70 ],
  ],

  [ "*.."+
    "xx."+
    "***",
    [ 1123, 1091, 1059 ],
    [ 99, 67, 35 ],
    [ 104, 72, 40 ],
  ],

  [ "..*"+
    ".xx"+
    "*x*",
    [ 1124, 1092, 1060 ],
    [ 100, 68, 36 ],
    [ 105, 73, 41 ],
  ],

  [ "*x*"+
    "*x."+
    "*x.",
    [ 1056 ],
    [ 32 ],
    [ 37 ],
  ],

  [ "*x*"+
    ".x*"+
    ".x*",
    [ 1058 ],
    [ 34 ],
    [ 39 ],
  ],

  [ "xx."+
    "**x"+
    "***",
    [ 1152, 1120, 1088 ],
    [ 128, 96, 64 ],
    [ 133, 101, 69 ],
  ],

  [ ".xx"+
    "x**"+
    "***",
    [ 1154, 1122, 1090 ],
    [ 130, 98, 66 ],
    [ 135, 103, 71 ],
  ],

  [ "***"+
    "*xx"+
    "*x.",
    [ 1024 ],
    [ 0 ],
    [ 5 ],
  ],

  [ "***"+
    "xx*"+
    ".x*",
    [ 1026 ],
    [ 2 ],
    [ 7 ],
  ],

  [ "***"+
    "*x."+
    "*..",
    [ 1027 ],
    [ 3 ],
    [ 8 ],
  ],

  [ "***"+
    ".x*"+
    "..*",
    [ 1028 ],
    [ 4 ],
    [ 9 ],
  ],

  [ "*.."+
    "xx."+
    "*xx",
    [ -1216, -1184 ],
    [ -1312, -1280 ],
    [ -1440, -1408 ],

  ],

  [ "..*"+
    ".xx"+
    "xx*",
    [ -1217, -1185 ],
    [ -1313, -1281 ],
    [ -1441, -1409 ]
  ],
]

function tilePatternMatch(candidate, actual) {
  // In candidate patterns:
  // . background tile
  // x initial tile
  // * any tile / doesn't matter
  // In actual patterns:
  // . background tile
  // x initial tile
  // ? unknown tile (matches only *)
  for (let i = 0; i < 9; i++) {
    if (candidate[i] === '*') {
      continue;
    }
    if (candidate[i] !== actual[i]) {
      return false;
    }
  }
  return true;
}

function isTileInSet(tile, set) {
  if (tile === null) {
    return false;
  }

  const tileset = tile.tileset;
  const tileId = tile.id;

  if (tileset.name !== SRC_TILESET) {
    return false;
  }

  return set.has(tileId);
}

const action = tiled.registerAction("Hck8AutoWall", action => {
  if (!tiled.activeAsset.isTileMap) {
    tiled.error("Hck8AutoWall: Switch to a map tab");
    return;
  }

  const map = tiled.activeAsset as TileMap;

  let dstLayer = null;
  let srcLayer = null;

  for (let i = 0; i < map.layerCount; i++) {
    const layer = map.layerAt(i);
    if (layer.name === DST_LAYER) {
      dstLayer = layer as TileLayer;
    } else if (layer.name === SRC_LAYER) {
      srcLayer = layer as TileLayer;
    }

    if (dstLayer && srcLayer) {
      break;
    }
  }

  if (srcLayer === null || dstLayer === null) {
    tiled.error(
        "Hck8AutoWall: Make sure to create Ground0 and " +
        "GroundAutoWallsDontEdit layers."
    );
    return;
  }

  if (!srcLayer.isTileLayer || !dstLayer.isTileLayer) {
    tiled.error(
        "Hck8AutoWall: Make sure Ground* layers are tile layers."
    );
    return;
  }

  const usedTilesets = map.usedTilesets();
  let dstTileset = null
  for (let i = 0; i < usedTilesets.length; i++) {
    if (usedTilesets[i].name === DST_TILESET) {
      dstTileset = usedTilesets[i];
      break;
    }
  }

  if (dstTileset === null) {
    tiled.error(
        "Hck8AutoWall: Can't find destination tileset in the map (wasn't used?)"
    );
    return;
  }

  // Clear destination layer.
  const dstEdit = dstLayer.edit();
  for (let j = 0; j < dstLayer.height; j++) {
    for (let i = 0; i < dstLayer.width; i++) {
      dstEdit.setTile(i, j, null);
    }
  }


  const importantTiles = new Set();
  for (let j = 2; j < srcLayer.height; j++) {
    for (let i = 1; i < srcLayer.width -1; i++) {
      const tile = srcLayer.tileAt(i, j);
      if (tile === null) {
        continue;
      }

      if (!isTileInSet(tile, SRC_INIT_TILEID)) {
        continue;
      }

      /*
      if (j < 2) {
        tiled.error(
            "Hck8AutoWall: Source layer has initial tiles in top rows."
        );
        return;
      }

      if (i < 1 || i >= srcLayer.width - 1) {
        tiled.error(
            "Hck8AutoWall: Source layer has initial tiles in edge columns."
        );
        return;
      }
      */

      let pattern = "";
      for (let y = j - 1; y <= j + 1; y++) {
        for (let x = i - 1; x <= i + 1; x++) {
          if (x == i && y == j) {
            pattern += "x";
            continue;
          }

          let nearbyTile = srcLayer.tileAt(x, y);

          if (isTileInSet(nearbyTile, SRC_BACKGROUND_TILEID)) {
            pattern += ".";
            continue;
          }

          if (isTileInSet(nearbyTile, SRC_INIT_TILEID)) {
            pattern += "x";
            continue;
          }

          pattern += "?";
        }
      }

      for (let entry = 0; entry < SRC_PATTERNS.length; entry++) {
        const patternEntry = SRC_PATTERNS[entry];
        const candidatePattern = patternEntry[0];
        if (tilePatternMatch(candidatePattern, pattern)) {

          const tileGroup = SRC_TILE_GROUPS.get(tile.id);
          if (tileGroup === undefined) {
            tiled.error(
                `Hck8AutoWall: Unknown tile group for tile (${tile.id}).`
            );
            return;
          }
          const patternTiles = patternEntry[1 + tileGroup];

          for (let idIdx = 0; idIdx < patternTiles.length; idIdx++) {
            let tileId = patternTiles[idIdx];
            const tileX = i;
            const tileY = j - idIdx;
            const tileIdx = tileX + tileY * srcLayer.width;

            if (importantTiles.has(tileIdx)) {
              continue;
            }

            if (tileId < 0) {
              tileId = -tileId;
              importantTiles.add(tileIdx);
            }

            dstEdit.setTile(tileX, tileY, dstTileset.tile(tileId));
          }
          //break;  // Maybe remove?
        }
      }
    }
  }

  // dstEdit.setTile(x, y, tile)

  dstEdit.apply();
});

action.text = "Hck8 Auto Wall";

tiled.extendMenu("Map", [
  { action: "Hck8AutoWall", before: "MapProperties" },
  { separator: true }
]);
