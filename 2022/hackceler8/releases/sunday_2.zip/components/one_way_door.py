# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math

import collision
from gametree import *

class OneWayDoor(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.player_direction = Vector2f(0, 0)

    def tick(self):
        self.player_direction = environ.game.player.direction

    def on_collision_enter(self, other: Entity):
        if other != environ.game.player.entity:
            return

        door_rotation = math.radians(self.entity.transform.rotation)
        door_direction = Vector2f(round(math.cos(door_rotation), 1), round(math.sin(door_rotation), 1))
        door_position = self.entity.transform.position
        dot = self.player_direction.dot(door_direction)
        wrong_way = dot <= 0

        self.entity.get_component(collision.Collider).solid = wrong_way
