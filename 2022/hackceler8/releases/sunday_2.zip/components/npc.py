# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from gametree import *
import components.grate_door
import settings
import persistent_state
import keys
import gametree
if settings.environ == 'client':
    from menus import chat


class NPC1(serialize.SerializableObject):
    def __init__(self, flag_door):
        for comp in flag_door.components:
            if isinstance(comp, components.grate_door.GrateDoor):
                self.flag_door = comp
        pass

    def on_open(self):
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Hello")

    def on_query(self, txt):
        reply = "..."
        if txt == "blah":
            reply = "blah to you too! The door is now open."
            self.flag_door.locked = False
        else:
            reply = "Interesting... Tell me more!"

        #print(txt, reply)

        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply)

phil_dialogue = {
    "Who are you?": "I am the chief guard in the Palace of the Shifted Bit.",
    "Where is the King?": "The King of Chilly Wind is busy at the forge, crafting a new silver sword.",
    "Could you give me a tour?": "At the North end of the castle is an unremarkable series of islands. At the south end is the Chamber of the Great Flag. To the West is the Greater Ashtray Maze and the Divinity Machine. To the East is the Royal Forest."
}
phil_no_flag_dialogue = {
    "Please let me past.": "Only the Worthy may gaze upon the Great Flag. You are not Worthy.",
}
phil_flag_dialogue = {
    "Please let me past.": "You are Worthy."
}

class Phil(serialize.SerializableObject):
    def __init__(self, component):
        self.component = component
        self.entity = component.entity
        self.spoke_once = False
        self.zoom = None
        self.summon_latch = utils.Latch()
        self.origin = gametree.Vector2f(self.entity.transform.position.x, self.entity.transform.position.y)
        pass

    def has_flag(self):
        return persistent_state.persistent_state.obtained_flags.get("blue", False)

    def player_near_door(self):
        return True

    def dialogue_dict(self):
        dialogue = phil_dialogue
        if self.has_flag():
            dialogue = {**dialogue, **phil_flag_dialogue}
        elif self.player_near_door():
            dialogue = {**dialogue, **phil_no_flag_dialogue}
        return dialogue

    def on_open(self, message=None):
        if settings.environ == "client":
            dialogue = phil_dialogue
            if self.has_flag():
                dialogue = {**dialogue, **phil_flag_dialogue}
            elif self.player_near_door():
                dialogue = {**dialogue, **phil_no_flag_dialogue}
            if message is None:
                if self.spoke_once:
                    message = "Yes?"
                else:
                    message = """Hello. Welcome to the Castle of the Shifted Bit. The King of Chilly Wind is out until Monday; however, I would be happy to answer your questions before then. Just push < anywhere in the castle and I'll come help."""
            environ.client.pending_chat = chat.ChatMenu(
                environ.game,
                message,
                dialogue.keys())
        self.spoke_once = True

    def on_query(self, txt):
        response = self.dialogue_dict().get(txt, "Shenanigans!")
        if settings.environ == "client":
            self.on_open(response)
        if response == "You are Worthy." and self.has_flag():
            self.entity.parent.remove_child(self.entity)

    def tick(self):
        pressed, released = self.summon_latch.update(keys.LESS in environ.game.held_keys or keys.COMMA in environ.game.held_keys)
        if pressed:
            self.zoom = "player"

        if self.zoom == "player":
            player_distance = utils.distance(self.entity.transform.position, environ.game.player.transform.position)
            if player_distance > 32:
                utils.move_towards(self.entity.transform.position, environ.game.player.transform.position, 512)
            elif player_distance <= 32:
                self.component.on_activation(self)
                self.zoom = "in_conversation"

        if self.zoom == "in_conversation" and environ.game.now_talking_to is None:
            self.zoom = "return"

        if self.zoom == "return":
            origin_distance = utils.distance(self.entity.transform.position, self.origin)
            if origin_distance > 1:
                utils.move_towards(self.entity.transform.position, self.origin, 512)
            elif origin_distance <= 1:
                self.zoom = None

matt_dialogue = {
    "Where are we?": "We are in the land of Misc. Beautiful, isn't it?",
    "What are you doing here?": "I come here pretty often these days. I like to relax, sit back, and enjoy the scenery. How about you?",
    "What are those stones down there?": "Ah, those. According to an old legend, there is a great treasure buried past them. Many have tried to get past them, but so far all those who tried have failed.",
}

class Matt(serialize.SerializableObject):
    def __init__(self, component):
        self.spoke_once = False

    def on_open(self, message=None):
        if settings.environ == "client":
            if message is None:
                if self.spoke_once:
                    message = "Yes?"
                else:
                    message = "Welcome, traveller! I'm Matt. What brings you here?"
            environ.client.pending_chat = chat.ChatMenu(environ.game, message, matt_dialogue.keys())
        self.spoke_once = True

    def on_query(self, txt):
        response = matt_dialogue.get(txt, "Shenanigans!")
        if settings.environ == "client":
            self.on_open(response)

    def tick(self):
        pass


class NPC(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initialized = False
        self.npc = None

    def update_animation(self, frameset):
        if frameset != self.entity.frameset:
            self.entity.frameset = frameset

    def tick(self):
        # Cannot do this in __init__, the fields are not set there yet.
        if not self.initialized:
            self.initialized = True
            if self.name == "Phil":
                self.npc = Phil(self)
            elif self.name == "Matt":
                self.npc = Matt(self)
            else:
                raise Exception("Unknown NPC")
        if self.npc is not None and hasattr(self.npc, "tick"):
            self.npc.tick()

    def on_activation(self, caller):
        environ.game.now_talking_to = self.npc
        environ.game.now_talking_to.on_open()

    def on_collision_enter(self, other):
        pass

    def while_colliding(self, other):
        pass

    def on_collision_exit(self, other):
        pass

    def duplicate(self, new_entity):
        ret = self.__class__()
        return ret
