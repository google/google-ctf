<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="tile_set_image" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="48" columns="8" backgroundcolor="#5500ff">
 <image source="../../images/tmw_desert_spacing.png" width="265" height="199"/>
</tileset>
