# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from gametree import *
import math
import sys

import keys as keys_enum
import game
import collision
import map_loader
import utils
import serialize
from components import collectable
from typing import List
import environ


def gen_framesets():
    return {
    "homing":  Frameset(frameset="homing"),
    "exploding":  Frameset(frameset="exploding"),
    }

class HomingBullet(Component):
    additional_framesets = gen_framesets()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.expode_timer = None
        self.original_size = None
        self.spawn_position = None
        self.spawn_timer = None
        self.expire_timer = None
        self.expire_time = -1.0


    def tick(self):
        if self.spawn_timer is not None:
            if self.spawn_timer.tick():
                self.enabled = True
                self.entity.transform.size.x = self.original_size.x
                self.entity.transform.size.y = self.original_size.y
            else:
                self.entity.transform.size.x = self.original_size.x * self.spawn_timer.fraction_done()
                self.entity.transform.size.y = self.original_size.y * self.spawn_timer.fraction_done()
                self.entity.transform.position.x = self.spawn_position.x + self.original_size.x * (1 - self.spawn_timer.fraction_done()) / 2
                self.entity.transform.position.y = self.spawn_position.y - self.original_size.y * (1 - self.spawn_timer.fraction_done()) / 2
                self.entity.transform.size.y = self.original_size.y * self.spawn_timer.fraction_done()
                return


        if not self.enabled:
            return

        utils.move_towards(self.transform.position, environ.game.player.entity.transform.position, self.speed)
        if self.expode_timer is not None and self.expode_timer.tick():
            self.entity.parent.remove_child(self.entity)

        elif self.expire_timer is not None and self.expire_timer.tick():
            self.entity.parent.remove_child(self.entity)
        pass

    def on_collision_enter(self, other):
        if other == environ.game.player.entity:
            environ.game.kill_player()
            self.entity.frameset = "exploding"
            self.expode_timer = utils.Timer(time=0.195)
        pass

    def added(self):
        self.original_size = Vector2f(self.entity.transform.size.x, self.entity.transform.size.y)

    def while_colliding(self, other: Entity):
        other_collider = other.get_component(collision.Collider)
        if other_collider is None:
            other_collider = other.get_component(map_loader.TileLayer).spatial_hash
        else:
            return

        if other_collider.solid:
            collider = self.entity.get_component(collision.Collider)

            mtv = collider.minimum_translation_vector(other_collider)
            if mtv is None:
                sys.stderr.write("Got collision from shapely that doesn't match MTV.")
                return
            self.transform.position += mtv


    def duplicate(self, new_entity):
        ret = self.__class__()
        if self.expode_timer is not None:
            raise RuntimeError("Duplicating expiring HomingBullet not supported.")
        ret.enabled = False
        ret.speed = self.speed
        ret.expire_time = self.expire_time
        ret.spawn_timer = utils.Timer(time=1)
        if self.expire_time >= 0:
            ret.expire_timer = utils.Timer(time=self.expire_time)

        return ret

class HomingSpawner(Component):
    def on_activation(self, caller):
        dup = self.homing_bullet_reference.duplicate(name="homing_bullet")
        dup.transform.position.x = self.entity.transform.position.x
        dup.transform.position.y = self.entity.transform.position.y
        dup.get_component(HomingBullet).spawn_position = Vector2f(
            self.entity.transform.position.x, self.entity.transform.position.y)
        environ.game.default_for_new_objects.add_child(dup)
    pass
